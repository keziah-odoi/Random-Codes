package Admin;

public class StudentData {
}
